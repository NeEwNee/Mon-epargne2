# Mon Épargne App Pro

Version GitHub Pages avec code PIN, historique et simulation.

📈 Pour activer sur GitHub Pages :
- Settings > Pages > Deploy from `main`, folder `/ (root)`.